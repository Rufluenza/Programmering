

class Enemy {
  constructor(x, y, type=0) {
    this.x = x
    this.y = y
    this.type = type
    this.imgNum = 0
    this.imgCounter = 0
    this.imgMod = 60/2
    this.w = enemySprites[this.type][0].width*game.ps
    this.h = enemySprites[this.type][0].height*game.ps
    this.canShoot = false
    this.setShootCooldown = 60*10 // every 10 seconds
    this.shootCooldown = random(this.setShootCooldown)
    
  }
  move() {
    this.x += enemyDir
  }
  checkWallCol() {
    if (this.x + this.w >= width || this.x <= 0) {
      return true
    }
    return false
  }
  show() {
    fill(0, 255, 0)
    //rect(this.x, this.y, this.w, this.h)
    this.imgCounter++
    if (this.imgCounter > this.imgMod) {
      this.imgCounter = 0
      this.imgNum = (this.imgNum+1) % enemySprites[this.type].length
    }
    image(enemySprites[this.type][this.imgNum], this.x, this.y, this.w, this.h)
    
  }
  shoot() {
    if (!this.canShoot) {
      this.shootCooldown--
      if (this.shootCooldown <= 0) {
        this.canShoot = true
      }
    }
    if (this.canShoot) {
      this.canShoot = false
      this.shootCooldown = this.setShootCooldown + random(this.setShootCooldown/4)
      bullets[bullets.length] = new Bullet(this.x + (this.w/2), this.y + this.h, 1)
    }
  }
  update() {
    if (game.gameState != "game over") {
      this.move()
      this.show()
      this.shoot()
    }
  }
}
function enemyYUpdate() {
  for (var i = 0; i < enemies.length; i++) {
    enemies[i].y += enemyHeight
  }
}
function enemyUpdateDir() {
  for (var i = 0; i < enemies.length; i++) {
    if (enemies[i].checkWallCol()) {
      enemyYUpdate()
      return -enemyDir
    }
  }
  return enemyDir
}

class Player {
  constructor() {
    this.img = img.get(1, 49, 16, 8)
    this.w = this.img.width*3
    this.h = this.img.height*3
    this.x = (width/2)-(this.w/2)
    this.y = height-this.h-10
    this.speed = 3
    this.lives = 3
    this.canShoot = true
    this.shootCooldown = 0
    this.setShootCooldown = 60/3 // 3 times a second
    this.deadTimer = 60/2
    this.deadTime = 0
    this.isDead = false
    this.shootMechanic = "original" // "time" = cooldown based, "original" = when bullet is dead

  }
  move() {
    if (keyIsDown(LEFT_ARROW) && this.x - this.speed >= 0) {
      this.x -= this.speed
    }
    if (keyIsDown(RIGHT_ARROW) && this.x + this.w + this.speed <= width) {
      this.x += this.speed
    }
  }
  show() {
    fill(0, 255, 0)
    //rect(this.x, this.y, this.w, this.h)
    image(this.img, this.x, this.y, this.img.width*game.ps, this.img.height*game.ps)
  }
  shoot() {
    if (this.shootMechanic == "time") {
      // COOLDOWN
      if (!this.canShoot) {
        this.shootCooldown--
        if (this.shootCooldown <= 0) {
          this.canShoot = true
        }
      }
      // SHOOTING
      if (keyIsDown(32) && this.canShoot) {
        this.shootCooldown = this.setShootCooldown
        this.canShoot = false
        bullets[bullets.length] = new Bullet(this.x+(this.w/2), this.y, -1)
      }
    }
    else if (this.shootMechanic == "original") {
      
      // SHOOTING
      if (keyIsDown(32) && this.canShoot) { // Key 32 = spacebar
        this.canShoot = false
        bullets[bullets.length] = new Bullet(this.x+(this.w/2), this.y, -1)
      }
    }
  }
  update() {
    if (!this.isDead && game.gameState != "game over") {
      this.move()
      this.show()
      this.shoot()
    }
  }
}

function checkColObj(obj1, obj2) {
  if (obj1.x + obj1.w >= obj2.x && obj1.x <= obj2.x + obj2.w) {
    if (obj1.y + obj1.h >= obj2.y && obj1.y <= obj2.y + obj2.h) {
      return true
    }
  }
  return false
}

class Bullet {
  constructor(x, y, dir) {
    this.x = x
    this.y = y
    this.w = 3
    this.h = 7
    this.dir = dir
    this.speed = 7
  }
  move() {
    this.y += this.dir * this.speed
  }
  show() {
    fill(0, 255, 0)
    rect(this.x, this.y, this.w, this.h)
  }
  checkCol() {
    if (this.dir == -1) { // From the player
      if (this.y <= 0) {
        if (player.shootMechanic == "original") {
          player.canShoot = true
        }
        return true
      }
      //var removeAmount = 0 // this is because if we remove a enemy from the list the 
      for (var i = 0; i < enemies.length; i++) {
        if (checkColObj(this, enemies[i])) { // parse "self" in function
          let newScore = enemies[i].type == 0 ? 10 : enemies[i].type * 20
          explosions[explosions.length] = new Explosion(enemies[i].x, enemies[i].y, "enemy", 30)
          enemies.splice(i, 1)
          
          
          game.score += newScore
          if (player.shootMechanic == "original") {
            player.canShoot = true
          }
          return true
        }
      }
    } else {
      if (this.y >= height) {
        return true
      }
      if (checkColObj(this, player)) {
        player.lives--
        explosions[explosions.length] = new Explosion(player.x, player.y, "player", 30)
        player.isDead = true
        return true
      }
    }
    return false
  }
  update() {
    this.move()
    this.show()

  }
}

class Explosion {
  constructor(x, y, type, timer=30) {
    this.x = x
    this.y = y
    this.type = type
    this.timer = timer
    this.time = 0
    
  }
  show() {
    if (this.type == "enemy") {
      image(expImg, this.x, this.y, expImg.width*game.ps, expImg.height*game.ps)
    }
    else if (this.type == "player") {
      var imgNum = 0
      if (this.time > this.timer/2) {
        imgNum = 1
      }
      image(expImgPlayer[imgNum], this.x, this.y, expImgPlayer[imgNum].width*game.ps, expImgPlayer[imgNum].height*game.ps)
    }
    
  }
  update() {
    this.time++
    if (this.time >= this.timer) {
      return true
    }
    return false
  }
}




function waveUpdater() {
  if (enemies.length == 0 && waveNum < wave.length) { // Er der ikke nogle fjender tilbage? Og tjek om vi ikke prøver at index en wave som ikke er lavet.
    for (var col = 0; col < wave[waveNum][0]; col++) { // Loop igennem antal fjender på x-aksen
      for (var row = 0; row < wave[waveNum][1]; row++) { // Loop igennem antal fjender på y-aksen
        enemies[enemies.length] = new Enemy(col*40+30, row * (enemyHeight+10)+20, row%3)
        // Enemy(x, y, type)
        // Vi bruger enemies.length for at sørge for at index arrayet i slutningen hvor der ikke er noget endnu.
      }
    }
    waveNum++
  }
}

// GAME
class Game {
  constructor(w, h, bg, speed) {
    this.w = w
    this.h = h
    this.bg = bg
    this.speed = speed
    this.score = 0
    this.highScore = 0
    this.ps = 3 // pixel size (upscale size)
    this.cs = 8*this.ps // Char size
    this.gameState = "play"
  }
  start() {
    background(this.bg)
    createCanvas(this.w, this.h)

  }
  showScore(x=0, y=0) {
    var scoreText = "score "+this.score.toString() //[18, 2, 14, 17, 4]//"score"
    showText(scoreText, x, y+this.cs)
    /*
    var scoreStr = this.score.toString()
    for (var i = 0; i < scoreStr.length; i++) {
      var number = parseInt(scoreStr[i])
      image(sprNum[number], x+(this.cs*scoreText.length+this.cs)+this.cs*i, y+this.cs, this.cs, this.cs)
    }
    */
  }
  showLives() {
    var livesText = "lives"//[11, 8, 21, 4, 18]
    showText(livesText, 0, this.cs*2.5)
    for (var i = 0; i < player.lives; i++) {
      image(player.img, (this.cs*livesText.length)+(player.img.width*this.ps)*i, this.cs*2.5, player.img.width*this.ps, player.img.height*this.ps)
    }
  }
  showHUD() {
    this.showScore()
    this.showLives()
  }
  showGameOver() {
    var gameOverText = "game over"
    var x = width/2 - this.cs*(gameOverText.length/2)
    showText(gameOverText, x, height/2-this.cs*2)
    if (this.score > this.highScore) {
      this.highScore = this.score
    }
    var highScoreText = "high score " + this.highScore.toString()
    showText(highScoreText, x, height/2)
    
    // SHOW SCORE
    this.showScore(x, height/2+this.cs)
    // TRY AGAIN BUTTON
    var tryAgainButton = showText("try again", x, height/2+this.cs*4)
    if (mouseIsPressed == true && mouseButton == LEFT) {
      if (mouseX >= tryAgainButton.x && mouseX <= tryAgainButton.ex) {
        if (mouseY >= tryAgainButton.y && mouseY <= tryAgainButton.ey) {
          this.restart()
        }
      }
    }
  }
  restart() {
    
    this.score = 0
    enemies = []
    bullets = []
    player = new Player()
    waveNum = 0
    newWave = true
    waveUpdater()
    this.gameState = "play"
  }
  update() {

    if (player.lives <= 0) {
      this.gameState = "game over"
      this.showGameOver()
    } else {
      enemyDir = enemyUpdateDir()
      for (var i = 0; i < bullets.length; i++) {
        bullets[i].update()
        if (bullets[i].checkCol()) {
          bullets.splice(i, 1)
          waveUpdater() // Check if we need to update the wave only when someone dies
        }
      }
      for (i = 0; i < enemies.length; i++) {
        enemies[i].update()
      }
      for (i = 0; i < explosions.length; i++) {
        explosions[i].show()
        if (explosions[i].update()) {
          if (explosions[i].type == "player") {
            player.isDead = false
          }
          explosions.splice(i, 1)
        }
      }
      player.update()
      this.showHUD()
    }
  }
}

function showText(text, x, y) { // text = string, x og y er start koordinaterne til teksten
  for (var i = 0; i < text.length; i++) { // loop igennem hele teksten
    if (unchar(text[i]) != 32) { // Hvis det ikke er mellemrum
      var shownImg = chars[unchar(text[i])-97] // -97 fordi char for "a" er 97
      if (unchar(text[i]) >= 48 && unchar(text[i]) <= 57) { // hvis det er et tal
        // char 48 = "0", char 57 = "9"
        shownImg = sprNum[unchar(text[i])-48] // -48 fordi char 48 = "0"
      }
      image(shownImg, x+game.cs*i, y, game.cs, game.cs) // vis billedet
      // game.cs = character image size (8) * upscale amount (3)
    }
  }
  return { // Bruges til fx "Try Again" knap
    "x": x, // start x
    "y": y, // start y
    "ex": x+game.cs*text.length, // start x + enkelt billede længde * tekstens antal bogstaver eller tal (altså antal af billeder der er blevet vist)
    "ey": y+game.cs // start y + billede højde
  }
}

// GAME
game = new Game(700, 600, 0, 1)
let tryAgainButton
// ENEMIES
let enemies = []
let enemyDir = 1
let enemySpawnAmount = 4
let enemyHeight = 20
let waveNum = 0
let newWave = false
let wave = [[6, 2], [7, 3], [8, 5]]

// PLAYER
let player

// BULLETS
let bullets = []
let explotions = []

// EXPLOSIONS
let explosions = []
let expImg
let expImgPlayer


// IMAGES
let img

let sprites = []
let enemySprites = []
let chars = []
let sprNum = []
let alphabet = ['A', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
let charSize
function setEnemySprites() {
  enemySprites[0] = [img.get(39, 1, 12, 7), img.get(39, 11, 12, 7)]
  enemySprites[1] = [img.get(22, 1, 11, 7), img.get(22, 11, 11, 7)]
  enemySprites[2] = [img.get(5, 1, 8, 7), img.get(5, 11, 8, 7)]
}
function setCharSprites() {
  var loopAmount = 0
  var w = 8
  var h = 8
  for (var row = 0; row < 6; row++) {
    for (var col = 0; col < 8; col++) {
      var setImg = img.get((col*w)+col+1, (row*h)+69+row, w, h)
      if (loopAmount < 26) {
        chars[loopAmount] = setImg
      } else if (loopAmount < 36) {
        sprNum[loopAmount-26] = setImg
      }
      loopAmount++
    }
  }
}

function preload() {
  img = loadImage("SpaceInvadersNEW.png")
}
function setup() {
  setEnemySprites()
  setCharSprites()
  expImg = img.get(55, 1, 16, 8)
  expImgPlayer = [img.get(19, 49, 16, 8), img.get(37, 49, 16, 8)]
  charSize = chars[0].width*3
  game.start()
  player = new Player()
  waveUpdater()

}

function draw() {
  background(game.bg);
  fill(0, 255, 0)
  noSmooth()
  game.update()
}